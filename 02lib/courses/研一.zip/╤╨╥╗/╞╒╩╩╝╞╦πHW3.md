
# 问题描述

本数据集包含了一项航空公司乘客满意度调查。哪些因素与乘客的满意度（或不满意度）高度相关？您能预测乘客满意度吗？

# 数据集描述

本数据集包含25个 Column，其中 “Satisfaction” 是待预测 Label

以下是各 Column 的含义：

| Column                                   | Description                                                                         |
| ------------------------------------ | -------------------------------------------------------------------------- |
| _Gender_                            | Gender of the passengers (Female, Male)                                    |
| _Customer Type_                     | The customer type (Loyal customer, disloyal customer)                      |
| _Age_                               | The actual age of the passengers                                           |
| _Type of Travel_                    | Purpose of the flight of the passengers (Personal Travel, Business Travel) |
| _Type of Travel_                    | Purpose of the flight of the passengers (Personal Travel, Business Travel) |
| _Class_                             | Travel class in the plane of the passengers (Business, Eco, Eco Plus)      |
| _Flight distance_                   | The flight distance of this journey                                        |
| _Inflight wifi service_             | Satisfaction level of the inflight wifi service (0:Not Applicable;1-5)     |
| _Departure/Arrival time convenient_ | Satisfaction level of Departure/Arrival time convenient                    |
| _Ease of Online booking_            | Satisfaction level of online booking                                       |
| _Gate location_                     | Satisfaction level of Gate location                                        |
| _Food and drink_                    | Satisfaction level of Food and drink                                       |
| _Online boarding_                   | Satisfaction level of online boarding                                      |
| _Seat comfort_                      | Satisfaction level of Seat comfort                                         |
| _Inflight entertainment_            | Satisfaction level of inflight entertainment                               |
| _On-board service_                  | Satisfaction level of On-board service                                     |
| _Leg room service_                  | Satisfaction level of Leg room service                                     |
| _Baggage handling_                  | Satisfaction level of baggage handling                                     |
| _Check-in service_                  | Satisfaction level of Check-in service                                     |
| _Inflight service_                  | Satisfaction level of inflight service                                     |
| _Cleanliness_                       | Satisfaction level of Cleanliness                                          |
| _Departure Delay in Minutes_        | Minutes delayed when departure                                             |
| _Arrival Delay in Minutes_          | Minutes delayed when Arrival                                               |
| _Satisfaction_                      | Airline satisfaction level(Satisfaction, neutral or dissatisfaction)       |


# 数据预处理

## 基本统计

首先对数据进行基本的统计，这有助于我们后续进行的数据清洗、标准化等操作。

```python
import pandas as pd 

train = pd.read_csv("/kaggle/input/airline-passenger-satisfaction/train.csv")

desc = pd.DataFrame(train.describe(include = 'all').transpose())#transpose转置
desc
```

| count                             | unique   | top | freq                    | mean  | std          | min          | 25%  | 50%      | 75%     | max      |          |
| --------------------------------- | -------- | --- | ----------------------- | ----- | ------------ | ------------ | ---- | -------- | ------- | -------- | -------- |
| id                                | 103904.0 | NaN | NaN                     | NaN   | 64924.210502 | 37463.812252 | 1.0  | 32533.75 | 64856.5 | 97368.25 | 129880.0 |
| Gender                            | 103904   | 2   | Female                  | 52727 | NaN          | NaN          | NaN  | NaN      | NaN     | NaN      | NaN      |
| Customer Type                     | 103904   | 2   | Loyal Customer          | 84923 | NaN          | NaN          | NaN  | NaN      | NaN     | NaN      | NaN      |
| Age                               | 103904.0 | NaN | NaN                     | NaN   | 39.379706    | 15.114964    | 7.0  | 27.0     | 40.0    | 51.0     | 85.0     |
| Type of Travel                    | 103904   | 2   | Business travel         | 71655 | NaN          | NaN          | NaN  | NaN      | NaN     | NaN      | NaN      |
| Class                             | 103904   | 3   | Business                | 49665 | NaN          | NaN          | NaN  | NaN      | NaN     | NaN      | NaN      |
| Flight Distance                   | 103904.0 | NaN | NaN                     | NaN   | 1189.448375  | 997.147281   | 31.0 | 414.0    | 843.0   | 1743.0   | 4983.0   |
| Inflight wifi service             | 103904.0 | NaN | NaN                     | NaN   | 2.729683     | 1.327829     | 0.0  | 2.0      | 3.0     | 4.0      | 5.0      |
| Departure/Arrival time convenient | 103904.0 | NaN | NaN                     | NaN   | 3.060296     | 1.525075     | 0.0  | 2.0      | 3.0     | 4.0      | 5.0      |
| Ease of Online booking            | 103904.0 | NaN | NaN                     | NaN   | 2.756901     | 1.398929     | 0.0  | 2.0      | 3.0     | 4.0      | 5.0      |
| Gate location                     | 103904.0 | NaN | NaN                     | NaN   | 2.976883     | 1.277621     | 0.0  | 2.0      | 3.0     | 4.0      | 5.0      |
| Food and drink                    | 103904.0 | NaN | NaN                     | NaN   | 3.202129     | 1.329533     | 0.0  | 2.0      | 3.0     | 4.0      | 5.0      |
| Online boarding                   | 103904.0 | NaN | NaN                     | NaN   | 3.250375     | 1.349509     | 0.0  | 2.0      | 3.0     | 4.0      | 5.0      |
| Seat comfort                      | 103904.0 | NaN | NaN                     | NaN   | 3.439396     | 1.319088     | 0.0  | 2.0      | 4.0     | 5.0      | 5.0      |
| Checkin service                   | 103904.0 | NaN | NaN                     | NaN   | 3.30429      | 1.265396     | 0.0  | 3.0      | 3.0     | 4.0      | 5.0      |
| Inflight entertainment            | 103904.0 | NaN | NaN                     | NaN   | 3.358158     | 1.332991     | 0.0  | 2.0      | 4.0     | 4.0      | 5.0      |
| On-board service                  | 103904.0 | NaN | NaN                     | NaN   | 3.382363     | 1.288354     | 0.0  | 2.0      | 4.0     | 4.0      | 5.0      |
| Leg room service                  | 103904.0 | NaN | NaN                     | NaN   | 3.351055     | 1.315605     | 0.0  | 2.0      | 4.0     | 4.0      | 5.0      |
| Baggage handling                  | 103904.0 | NaN | NaN                     | NaN   | 3.631833     | 1.180903     | 1.0  | 3.0      | 4.0     | 5.0      | 5.0      |
| Checkin service                   | 103904.0 | NaN | NaN                     | NaN   | 3.30429      | 1.265396     | 0.0  | 3.0      | 3.0     | 4.0      | 5.0      |
| Inflight service                  | 103904.0 | NaN | NaN                     | NaN   | 3.640428     | 1.175663     | 0.0  | 3.0      | 4.0     | 5.0      | 5.0      |
| Cleanliness                       | 103904.0 | NaN | NaN                     | NaN   | 3.286351     | 1.312273     | 0.0  | 2.0      | 3.0     | 4.0      | 5.0      |
| Departure Delay in Minutes        | 103904.0 | NaN | NaN                     | NaN   | 14.815618    | 38.230901    | 0.0  | 0.0      | 0.0     | 12.0     | 1592.0   |
| Arrival Delay in Minutes          | 103594.0 | NaN | NaN                     | NaN   | 15.178678    | 38.698682    | 0.0  | 0.0      | 0.0     | 13.0     | 1584.0   |
| satisfaction                      | 103904   | 2   | neutral or dissatisfied | 58879 | NaN          | NaN          | NaN  | NaN      | NaN     | NaN      | NaN      |

然后统计一下空值和其他基本统计数据

```python
def summary_stats(df): 
    print(f'The shape of the data is: {df.shape}')
    summary = pd.DataFrame(df.dtypes, columns = ['data type'])
    summary['Number of missing values'] = df.isnull().sum().values 
    summary['% of missing values'] = df.isnull().sum().values / len(df) * 100 
    summary['min value'] = desc['min'].values
    summary['mean value'] = desc['mean'].values
    summary['max value'] = desc['max'].values
    summary['mode value'] = df.mode().values[0]
    return summary

summary_stats(train)
```

|                                   | data type | Number of missing values | % of missing values | min value | mean value   | max value | mode value              |
| --------------------------------- | --------- | ------------------------ | ------------------- | --------- | ------------ | --------- | ----------------------- |
| id                                | int64     | 0                        | 0.000000            | 1.0       | 64924.210502 | 129880.0  | 1                       |
| Gender                            | object    | 0                        | 0.000000            | NaN       | NaN          | NaN       | Female                  |
| Customer Type                     | object    | 0                        | 0.000000            | NaN       | NaN          | NaN       | Loyal Customer          |
| Age                               | int64     | 0                        | 0.000000            | 7.0       | 39.379706    | 85.0      | 39.0                    |
| Type of Travel                    | object    | 0                        | 0.000000            | NaN       | NaN          | NaN       | Business travel         |
| Class                             | object    | 0                        | 0.000000            | NaN       | NaN          | NaN       | Business                |
| Flight Distance                   | int64     | 0                        | 0.000000            | 31.0      | 1189.448375  | 4983.0    | 337.0                   |
| Inflight wifi service             | int64     | 0                        | 0.000000            | 0.0       | 2.729683     | 5.0       | 3.0                     |
| Departure/Arrival time convenient | int64     | 0                        | 0.000000            | 0.0       | 3.060296     | 5.0       | 4.0                     |
| Ease of Online booking            | int64     | 0                        | 0.000000            | 0.0       | 2.756901     | 5.0       | 3.0                     |
| Gate location                     | int64     | 0                        | 0.000000            | 0.0       | 2.976883     | 5.0       | 3.0                     |
| Food and drink                    | int64     | 0                        | 0.000000            | 0.0       | 3.202129     | 5.0       | 4.0                     |
| Online boarding                   | int64     | 0                        | 0.000000            | 0.0       | 3.250375     | 5.0       | 4.0                     |
| Seat comfort                      | int64     | 0                        | 0.000000            | 0.0       | 3.439396     | 5.0       | 4.0                     |
| Checkin service                   | int64     | 0                        | 0.000000            | 0.0       | 3.30429      | 5.0       | 4.0                     |
| Inflight entertainment            | int64     | 0                        | 0.000000            | 0.0       | 3.358158     | 5.0       | 4.0                     |
| On-board service                  | int64     | 0                        | 0.000000            | 0.0       | 3.382363     | 5.0       | 4.0                     |
| Leg room service                  | int64     | 0                        | 0.000000            | 0.0       | 3.351055     | 5.0       | 4.0                     |
| Baggage handling                  | int64     | 0                        | 0.000000            | 1.0       | 3.631833     | 5.0       | 4.0                     |
| Checkin service                   | int64     | 0                        | 0.000000            | 0.0       | 3.30429      | 5.0       | 4.0                     |
| Inflight service                  | int64     | 0                        | 0.000000            | 0.0       | 3.640428     | 5.0       | 4.0                     |
| Cleanliness                       | int64     | 0                        | 0.000000            | 0.0       | 3.286351     | 5.0       | 4.0                     |
| Departure Delay in Minutes        | int64     | 0                        | 0.000000            | 0.0       | 14.815618    | 1592.0    | 0.0                     |
| Arrival Delay in Minutes          | float64   | 310                      | 0.298352            | 0.0       | 15.178678    | 1584.0    | 0.0                     |
| satisfaction                      | object    | 0                        | 0.000000            | NaN       | NaN          | NaN       | neutral or dissatisfied |

## 空值

这里发现只有 “Arrival Delay in Minutes” 存在空值行，而且其数据分布和 ”Departure Delay in Minutes“ 基本一致。从现实角度来说，到达延迟和出发延迟近似也是合理的。所以，这里我们通过出发延迟来模拟到达延迟。

```python
for i in range(len(train)):
    if(pd.isna(train.loc[i, "Arrival Delay in Minutes"])):
        train.loc[i, "Arrival Delay in Minutes"] = train.loc[i, "Departure Delay in Minutes"]
```

## 标签编码

由于很多数据是枚举类型的标签，不利于机器学习算法进行利用，需要将其数值化。这里使用 sklearn 库的 LabelEncoder 来对数据进行处理。

```python
categorical_columns = train.select_dtypes(exclude='number').columns
le = LabelEncoder()
for col in categorical_columns:
    train[col] = le.fit_transform(train[col])
    test[col] = le.transform(test[col])

train[categorical_columns]
```

|Gender|Customer Type|Type of Travel|Class|satisfaction|
|---|---|---|---|---|
|0|1|0|1|2|0|
|1|1|1|0|0|0|
|2|0|0|0|0|1|
|3|0|0|0|0|0|
|4|1|0|0|0|1|
|...|...|...|...|...|...|
|103899|0|1|0|1|0|
|103900|1|0|0|0|1|
|103901|1|1|0|0|0|
|103902|0|1|0|1|0|
|103903|1|0|0|0|0|

103904 rows × 5 columns


## 标准化

在完成数据清洗和文本编码后，还需要对数据进行标准化处理。这是因为许多学习算法中目标函数的基础都是假设所有的特征都是零均值并且具有同一阶数上的方差。如果某个特征的方差比其他特征大几个数量级，那么它就会在学习算法中占据主导位置，导致学习器并不能像我们说期望的那样，从其他特征中学习。这里也使用 sklearn 的 StandardScaler

```python
ss = StandardScaler()
train[labels] = ss.fit_transform(train[labels])
train
```

|id|Gender|Customer Type|Age|Type of Travel|Class|Flight Distance|Inflight wifi service|Departure/Arrival time convenient|Ease of Online booking|...|Inflight entertainment|On-board service|Leg room service|Baggage handling|Checkin service|Inflight service|Cleanliness|Departure Delay in Minutes|Arrival Delay in Minutes|satisfaction|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|0|0.140077|1.015031|-0.472767|-1.745279|1.490614|2.264618|-0.731539|0.203579|0.616172|0.173776|...|1.231704|0.479403|-0.266840|0.311769|0.549799|1.156436|1.305870|0.266393|0.070988|-0.874473|
|1|-1.598276|1.015031|2.115208|-0.951360|-0.670865|-0.957054|-0.957184|0.203579|-0.695245|0.173776|...|-1.769081|-1.849161|1.253380|-0.535045|-1.821012|0.305848|-1.742292|-0.361375|-0.238223|-0.874473|
|2|1.203935|-0.985192|-0.472767|-0.885200|-0.670865|-0.957054|-0.047584|-0.549533|-0.695245|-0.541060|...|1.231704|0.479403|-0.266840|0.311769|0.549799|0.305848|1.305870|-0.387532|-0.392828|1.143545|
|3|-1.091678|-0.985192|-0.472767|-0.951360|-0.670865|-0.957054|-0.629246|-0.549533|1.271880|1.603448|...|-1.018885|-1.072973|1.253380|-0.535045|-1.821012|0.305848|-0.980251|-0.099805|-0.160920|-0.874473|
|4|1.451402|1.015031|-0.472767|1.430397|-0.670865|-0.957054|-0.978244|0.203579|-0.039537|0.173776|...|-0.268688|-0.296785|0.493270|0.311769|-0.240472|-0.544740|-0.218211|-0.387532|-0.392828|1.143545|
|...|...|...|...|...|...|...|...|...|...|...|...|...|...|...|...|...|...|...|...|...|...|
|103899|0.780671|-0.985192|2.115208|-1.083680|-0.670865|0.653782|-1.000307|-0.549533|-1.350954|-0.541060|...|-1.018885|-0.296785|-1.787061|0.311769|-1.030742|-0.544740|-0.980251|-0.309061|-0.392828|-0.874473|
|103900|0.218153|1.015031|-0.472767|0.636478|-0.670865|-0.957054|1.160869|0.956691|0.616172|0.888612|...|1.231704|1.255590|1.253380|1.158582|1.340069|1.156436|0.543829|-0.387532|-0.392828|1.143545|
|103901|0.104122|1.015031|2.115208|-0.620561|-0.670865|-0.957054|0.807860|-1.302646|-1.350954|-1.255895|...|0.481508|-0.296785|-1.026951|0.311769|1.340069|1.156436|0.543829|-0.204433|-0.032082|-0.874473|
|103902|-0.286977|-0.985192|2.115208|-1.149840|-0.670865|0.653782|-0.189991|-1.302646|-1.350954|-1.255895|...|-1.769081|0.479403|1.253380|-2.228672|1.340069|0.305848|-1.742292|-0.387532|-0.392828|-0.874473|
|103903|-0.062920|1.015031|-0.472767|-0.819040|-0.670865|-0.957054|0.535081|-1.302646|-0.039537|0.173776|...|-1.769081|-1.849161|-1.787061|0.311769|0.549799|-0.544740|-1.742292|-0.387532|-0.392828|-0.874473|

103904 rows × 25 columns

# 方法

这里采用一个经典的二分类问题模型——logestic 回归模型来进行预测。这里使用了sklearn.linear_model 提供的 LogisticRegression 进行训练，并输出预测准确率
预测之前，需要对测试数据集用跟训练集相同的方法预处理一遍数据，这里不再赘述。

```python
lr = LogisticRegression()
lr.fit(X_train, y_train)
y_pred = lr.predict(X_test)

Precision_score = precision_score(y_test, y_pred)
print("Precision Score:", Precision_score)
```

Precision Score: 0.8684114535838044

# 结果

通过一些基础的数据预处理和经典的 logestic 回归模型，我们在该二分类问题上获得了一个还不错的预测准确率。而不同变量对最终满意度的影响大小可以通过每个变量和满意度之间的相关系数进行估计，值越大，说明两者相关度越强：

```python
train.corr().loc['satisfaction'].abs().sort_values(ascending=False)
```

| satisfaction                      | 1.000000 |
| --------------------------------- | -------- |
| Online boarding                   | 0.503557 |
| Class                             | 0.449321 |
| Type of Travel                    | 0.449000 |
| Inflight entertainment            | 0.398059 |
| Seat comfort                      | 0.349459 |
| On-board service                  | 0.322383 |
| Leg room service                  | 0.313131 |
| Cleanliness                       | 0.305198 |
| Flight Distance                   | 0.298780 |
| Inflight wifi service             | 0.284245 |
| Baggage handling                  | 0.247749 |
| Inflight service                  | 0.244741 |
| Checkin service                   | 0.236174 |
| Checkin service                   | 0.236174 |
| Food and drink                    | 0.209936 |
| Customer Type                     | 0.187638 |
| Ease of Online booking            | 0.171705 |
| Age                               | 0.137167 |
| Arrival Delay in Minutes          | 0.057522 |
| Departure/Arrival time convenient | 0.051601 |
| Departure Delay in Minutes        | 0.050494 |
| id                                | 0.013734 |
| Gender                            | 0.012211 |
| Gate location                     | 0.000682 |
Name: satisfaction, dtype: float64

