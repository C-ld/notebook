## 1、特征提取和分析

### 1.1 时域特征提取及可视化


关键代码：
```python
fig, ax = plt.subplots()

ax.set_xlabel('channels')
ax.set_ylabel('mean(uV)')

mean = []
for i in cnt:
    mean.append(np.mean(i))
ax.plot(mean)
plt.show()
```


计算了118个channel在时域上的均值，可视化结果如下：

![[Pasted image 20231022134242.png]]

### 1.2 频域特征提取及可视化

关键代码：

```python
raw.plot_psd()
plt.show()
```

将每个channel的功率密度谱通过MNE库的API进行可视化，结果如下：

![[Pasted image 20231022134829.png]]

### 1.3 空域特征提取及可视化

```python
raw.compute_psd().plot_topomap()
plt.show()
```

通过MNE的compute_psd().plot_topomap()可以得到频率谱密度的空间分布特征如下：
![[Pasted image 20231022145524.png]]


## 2、EEG 特征提取和可视化

利用CSP算法提取特征，将特征作为输入，结合线性分类器进行运动想象的分类，使用了pipeline的方式以简化实现过程。

关键代码：
```python
csp.fit_transform(epochs_data, labels)
csp.plot_patterns(epochs.info, ch_type='eeg', units='Patterns (AU)', size=1.5)
plt.show()
```

绘制出CSP不同分量的模式图如下：

![[Pasted image 20231022170009.png]]

## 3、实战：运动想象分类

采用分类器：线性分类器 LDA
评价指标：线性分类器 LDA 的 score() 函数
实验过程及结果如下：


通过滑动窗口验证不同窗口期设置的情况下，CSP的特征分类效果。可以看到在约1.5s后，分类效果达到一个比较理想的水平。这说明被试者 al 在提示出现约 1.5 秒后出现较为明显的脑电波反馈。

关键代码：
```python
sfreq = raw.info["sfreq"]
w_length = int(sfreq * 0.5)  
w_step = int(sfreq * 0.1) 
w_start = np.arange(0, epochs_data.shape[2] - w_length, w_step)

scores_windows = []
for train_idx, test_idx in cv_split:
    y_train, y_test = labels[train_idx], labels[test_idx]
    X_train = csp.fit_transform(epochs_data_train[train_idx], y_train)
    X_test = csp.transform(epochs_data_train[test_idx])

    lda.fit(X_train, y_train)
    score_this_window = []
    for n in w_start:
        X_test = csp.transform(epochs_data[test_idx][:, :, n : (n + w_length)])
        score_this_window.append(lda.score(X_test, y_test))
    scores_windows.append(score_this_window)

w_times = (w_start + w_length / 2.0) / sfreq + epochs.tmin
plt.figure()
plt.plot(w_times, np.mean(scores_windows, 0), label="Score")
plt.axvline(0, linestyle="--", color="k", label="Onset")
plt.axhline(0.5, linestyle="-", color="k", label="Chance")
plt.xlabel("time (s)")
plt.ylabel("classification accuracy")
plt.title("Classification score over time")
plt.legend(loc="lower right")
plt.show()
```

![[Pasted image 20231022191847.png]]

作为进一步验证，基于不同的时间窗口分别训练 CSP 并用 LDA 进行分类。

关键代码：
```python
X_train = csp.fit_transform(epochs_data_train, labels)
lda.fit(X_train, labels)
tevents = np.zeros([56, 3], dtype=int)

for i in range(56):
    tevents[i][0] = epos[224+i]
    tevents[i][2] = tlabels[224+i]

epochs_test = Epochs(
    raw,
    tevents,
    event_id,
    train_tmin,
    train_tmax,
    proj=True,
    baseline=None,
    preload=True,
)
testlabels = epochs_test.events[:, -1] - 1

X_test = csp.transform(epochs_test.get_data())
y_test = tlabels[224:] - 1

print("tmin: ", train_tmin, ", tmax: ", train_tmax)
print("lda score: ",lda.score(X_test, y_test))
```

对比分类效果如下：

![[Pasted image 20231022212540.png]]
![[Pasted image 20231022212028.png]]
![[Pasted image 20231022212700.png]]
![[Pasted image 20231022212807.png]]
![[Pasted image 20231022212742.png]]
注：tmin 和 tmax 分别表示时间窗的起始点和终点。两者的值都是相对于提示（event）的时间点的偏移量。

## 4、总结

### 实验内容

在本次实验中，我学习了脑机接口中的基本数据格式，数据处理思路和处理方法。首先，我了解到了脑电信号在 mat 文件中的存储形式，并且学习了如何在 python 中读取 matlab 文件。在基本特征处理环节，我从时域、时频域、空域三个方面对数据进行了基本的分析，并通过 python 的 plot 和MNE 代码库的 API 来对相应特征进行可视化。在 EEG 特征提取和可视化环节，我通过 MNE 的 CSP 相关 API 进行了脑电信号的特征分析并进行了可视化。最后在实战环节，我采用线性分类器 LDA 进行分类并在测试集上测试了分类效果。

### 实验结论

本次脑机接口实验的主要目标是通过分析 EEG 信号和提取相应的特征来实现运动想象分类任务。通过对 EEG 信号进行多方面的分析，我们得出了以下结论：

任务 1 - EEG 信号分析：

1. 时域特征分析：对 EEG 信号的时域特征进行了分析，选取了均值特征进行可视化，该特征有助于了解信号的基本统计属性。
    
2. 频域/时频特征分析：通过对功率密度图进行可视化，揭示了信号中的频率成分。
    
3. 空域特征分析：研究了 EEG 信号的电极位置特征，这有助于理解信号在头皮上的分布。这对于确定信号的源很有帮助。


任务 2 - EEG 特征提取和可视化：

使用 CSP 算法，成功提取了与运动想象相关的脑电特征。这些特征能够很好地区分不同类型的运动想象。


任务 3 - 运动想象分类：

1. 设计了评价指标，用于评估分类器的性能。
    
2. 选取了线性分类器，采用了 LDA 算法，并使用 CSP 提取的 EEG 特征进行训练。
    
3. 在测试阶段，分类器成功实现了对运动想象的分类任务。获得了满意的分类性能，证明了该方法的有效性。

综上所述，本次实验的成功完成了对 EEG 信号的分析和分类。通过对信号的多层次分析和特征提取，能够有效地实现运动想象的分类，这对于脑机接口技术的进一步发展具有重要意义。
