
> 由于数据集中 waveform 第 1 列数据的含义并不明确，且第 2~5 列数据明确是手动分类的 Ground Truth，所以在本作业中，采用将第 2~5 列数据合并后重新 PCA+Kmeans 分类的方式以便于对分类准确率进行评估。

# 任务 1：神经元锋电位波形可视化和分析

## Spike 波形的 PCA 降维

本任务采用数据集中 `indy_20161005_06.mat` 中 channel 2 的数据进行 PCA 降维
![[Pasted image 20231110201403.png]]

从数据集中截取 channel 2 的数据并进行 PCA 降维的关键代码如下：
```python

	#setX: dataSet of X(multi columns)
	setX = []
	#x: dateSet of X(all in one column)
	x = []
	#ncol: number of not null columns
	ncol = 0
	for i in wf[1][1:]:
		if(type(i) == type(None)):
			continue
		ncol += 1
		if len(i.shape) == 1:
			setX.append([i])
			x.append(i)
			continue
		setX.append(i)
		for j in i:
			x.append(j)
	pca = PCA(n_components=ncol)
	newX = pca.fit_transform(x)

```

4 类波形的可视化代码：
```python
	fig, ax = plt.subplots(ncol)
	for i in range(0,ncol):
		for ix in setX:
			ax[i].plot(ix)
	plt.show()
```

可视化结果如下：
![[Pasted image 20231110211946.png]]


## 基于 K-means 的神经元锋电位分类

首先，Kmeans 降维需要确定超参数 n_clusters，这里通过比较不同降维维数下 SSE 的变化速率，选取曲线拐点来决定 n_clusters 。关键代码如下：
```python
     
	sse = []
	k = range(1, 10)
	
	for i in k:
		kms = KMeans(n_clusters=i).fit(newX)
		sse.append(kms.inertia_)
	
	plt.plot(k,sse,'bx-')
	plt.show()

```

绘制 “SSE 随 n_clusters 变化” 曲线如图：
![[Pasted image 20231110201310.png]]
可以看到，按照通常选取“拐点”的做法，可以设置 n_clusters 的值为 3 或 4，这里设置为 4。

分类后，选取前两个特征作为基底坐标系，可以画出 Kmeans 划分出 4 个 clusters 的散点图如下：
![[Pasted image 20231110204618.png]]

Kmeans 分类及可视化的关键代码如下：
```python
	kmeans = KMeans(n_clusters=ncol)
	#newX: X after PCA transform
	y = kmeans.fit_predict(newX)
	fig, ax = plt.subplots(2,ncol)
	for i in range(0,ncol):
		for ix in setX[i]:
			ax[0][i].plot(ix)
	for j in range(len(y)):
		ax[1][y[j]].plot(x[j])
	for i in range(2):
		for j in range(ncol):
			ax[i][j].set_ylim(-150,120)
	plt.show()
```

ground truth（第2~4列数据）和经过 PCA降维 + Kmeans分类的结果对比如下（由于是无监督分类，所以 Kmeans 的类别是乱序的，而非和 Ground Truth 依次对应）：
![[Pasted image 20231110203047.png]]
通过上图可以直观地看到，通过 PCA + Kmeans 对 channel 2 的 Ground Truth 进行重分类之后的数据和 Ground Truth 匹配度较高，效果较为理想。


# 任务 2：分类结果评估和分析

## 设计评价指标并与 Ground truth 比较

在本报告开头已经指出，本作业采用对第 2~5 列数据进行重分类的方式以便于验证算法效果。例如，对于 channel 2，我们采用训练好的 Kmeans 分类器分别对 Ground Truth 的每一类 Xi 分别进行预测得到结果 Yi，由于 Xi 的所有数据 label 相同，那么理想状态下分类器给出的 Yi 应该也都是相同的。那么对于 Xi 的预测准确率可以由下式得到：

> MAX( Yi 中的不同 label 的样本数量) / Xi 的样本数量

实现关键代码如下：

```python
	acc = 0
	for i in range(0, 4):
		cnt = [0, 0, 0, 0, 0]
		newXi = pca.transform(setX[i])
		yi = kmeans.predict(newXi)
		for yii in yi:
			cnt[yii] += 1
		# print(max(cnt)/len(yi)*100.0)
		acc += max(cnt)/len(yi)*100.0
	acc /= ncol
	accl[ncol-2].append(acc)
	print("channel idx: ", idx+1, ", ncol:", ncol, ", acc:", acc)
```

程序运行结果：
![[Pasted image 20231110212539.png]]

通过自动化设置，可以对数据集中 96 个 channel 的数据依次进行分类并评估分类准确率，这里忽略了没有 Ground Truth（第2~5列均为空 list） 或只有 1 类的 channel 数据（因为分类准确率必然是100%）：
![[Pasted image 20231110213256.png]]
![[Pasted image 20231110213327.png]]
![[Pasted image 20231110213352.png]]

## 分析现有方法的问题

发现有一些 channel 的准确率较低，如 channel 17 的准确率只有 55%

Ground Truth 和 Kmeans 可视化如下：
![[Pasted image 20231110215111.png]]

直观感觉上，Ground Truth 的两类波形较为类似，Kmeans 划分的两类差异更明显一些。怀疑是 PCA 降维没有把不同类的数据在前两个特征上较好地区分开，画图验证如下：
![[Pasted image 20231110222138.png]]
为了便于比较，进一步画出 Kmeans 的分类图：
![[Pasted image 20231110222343.png]]
可以看到两类数据在特征空间比较分散，且聚类的趋势并不明显，因而 Kmeans 算法的聚类效果不佳。

另，channel 26、27 的准确率也明显偏低，是因为这两个 channel 中的数据分布极不平衡，有一类的信号样本数量过少，同时不同类信号在特征空间上的分布不够分散。

channel 26 的 Kmeans 分类图如下：
![[Pasted image 20231110234416.png]]

channel 27 的 Kmeans 分类图如下：
![[Pasted image 20231110234549.png]]


# 总结

## 实验内容

在本实验中，我首先通过 PCA 对数据集中一个比较理想的 channel 的 Spike 波形进行了降维，然后通过 SSE 确定了合适的 Kmeans 超参数 n_clusters。在分类后对原 Spike 波形和分类结果进行了可视化，以呈现自动分类方法的有效性。在对 96 个 channel 依次分类并评估分类效果之后，分析了一些 bad case 以及自动分类失效的原因。

## 实验结论

对于比较理想的通道数据而言，PCA+Kmeans 可以发挥不错的效果

对于以下类型的信号，PCA+Kmeans 可能会失效：
1、在 PCA 的特征空间中，同类信号的聚类趋势不够明显
2、存在类型信号过少/过多，或不同类型的信号之间数量差异过大


